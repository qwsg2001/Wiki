package day03;

public enum Week {
	Monday,
	TUESDAY,
	WENESEDAY,
	THURSDAY,
	FRIDAY,
	SATERDAY,
	SUNDAY
}
