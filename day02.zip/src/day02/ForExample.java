package day02;

public class ForExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			//int sum = 0;
			//	for(int i = 0; i <100; i++) {
			//if(i % 3 == 0) {
			//sum += i;
			//}
			//}
			//System.out.println("3의 배수의 총합 : " + sum);

		
		//for(int i = 1; i <= 5; i++) {
		//for(int j = 1; j < i; j++) {
		//	System.out.print("*");	
		//	}System.out.println();	
				
				
		for(int a = 1; a <= 10; a++) {
			for(int b = 1; b < b; b++) {
				System.out.print("*");	
			}System.out.println();	
		
			}
		}
	}


