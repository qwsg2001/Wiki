package day02;

public class ForTEest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1부터 10까지의 합을 출력하시오 : 55
		// 2. 구구단 2단 출력하기
		
		//int sum = 2;	
		
		int sum = 2;
		for(int dan = 2; dan < 10; dan++) {
			for(int i = 1; i <= 9; i++) {
				System.out.println("2 x " + i + " = "+ sum * i);
				}
			
			
		}
	}
		

		//System.out.println("2부터 9까지의 곱 : " + sum);
		
		
	}
