package day02;

import java.util.Scanner;

public class Wiletest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//int i = 1;
		//int sum = 0;
		
		//while (1 <= 10) {
		//sum += i; 
		//i++;
		//System.out.println(" 1 ~ 10 까지의 합 ");
		//}
		
		
		//for(int m=2; m<=9; m++) {
		//	System.out.println(i + "x " + i + " = "+ sum * i);

		//	for(int i = 2; i <= 9; i++) {
		//System.out.println(i + "x " + i + " = "+ sum * i);
		//}
		
		//int dan = 2;
		
		// 초기식 .. 
		//while (dan<=9) {
		
		//	int gob = 1;

		//while(gob <= 9){
			//	// 종료 조건식
		//	System.out.printf("%d x %d= %d\n", dan, gob,(dan * gob));
		//	gob++; //증감식
		//}
		//System.out.println();
		//++dan;
		
		//String str = "";
		
		//Scanner scan = new Scanner(System.in);
		
		//		while(true) {
		//	str = scan.next();
		//	if(str.equals("x") || str.equals("X"));
		//		break;
		//}
		//System.out.println("bye~~");
		
		//boolean  bool=false;
		//double sum = 0.0;
		
		//while (!bool) {
		//	double no = Math.random();
		//	sum += no;
		//	Thread.sleep(2000);
		//	System.out.println("sum : " + sum);
		//	if(sum > 20) break;
			
		//	}
		
		
		
		
		
		

		
		
		
	}
}


