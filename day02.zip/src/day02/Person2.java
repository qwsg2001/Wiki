package day02;

public class Person2 {
	
	String name;
	int age;
	
	public void eat(String sr) {
			System.out.println(sr + "먹는다");
	}
	public void showInfo(String sr) {
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);	
	}
	public static void main(String args[]) {
		Person2 person2 = new Person2();

		
		
	}
}
