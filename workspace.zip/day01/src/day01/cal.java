package day01;

public class cal {
	private static void main() {
	
	}
}
