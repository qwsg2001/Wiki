package day01;

public class stringexaple2 {
	public static void main (String [] args) {
		
		String str2 = """
			{
				"id":"winter",
				"id":"눈송이"
				
			}		
				""";
		
			System.out.println(str2);
			
			
		
	}
}
