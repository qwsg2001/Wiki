package day01;

public class reperExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//문자열자료형을 기본자료형으로 변환하는 클래스
		int value = Integer.parseInt("100");
		
		double value2 = Double.parseDouble("3.14");
		
		System.out.println(value + 100);
		System.out.println(value2 + 100);

	}

}
