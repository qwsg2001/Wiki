package day01;

public class day01 {

	public static void main (String [] args) {
		//		System.out.println("Hello world");
		//		System.out.println("안녕!");

		/* 
		 행 주석 // 
		 // 범위 주석 : 현재 사용 하고 있는 주석 
		// 도큐먼트 주석
		/**  * 
		주석은 어디에나 작성할 수 있지만 문자열 내부에는 작성할 수 없다.

		 */

		//		int x;
		//		x = 1;
		//		int y = 2;
		//		int result = x+y;
		//		System.out.println(result);

		// 02 변수와 타입
		/*
		변수 선언 변수는
		 자바의 변수는 다양한 타입의 값을 저장 할 수 없다  즉 정수형 변수에는 정수값만 저장할 수 있고 실수형 변수에는 실수값만 저장할 수 있다.
		 변수를 사용 하려면 변수 선언이 필요한데 변수 선언은 어떤 타입의 데이터를 저장할 것인지 그리고 변수 이름이 무엇인지를 결정하는 것이다.
		 정수 (int) 값을 저장할 수 있는 age 뱐수 선언
		 실수(double) 값을 저장할 수 있는 value 변수 선언

		 변수 이름은 첫 번째 글자가 문자여야 하고 중간부터는 문자, 숫자, $, _ 를 사용할 수 있다.
		 첫 문자를 소문자로 시작하되 개별 스타일로 작성하는 것이 관례이다.

		 캐멀 스타일 
		 낙타의 등처럼 대소문자가 섞여 있도록 작성하는 스타일을 말한다.

		 자바 소스파일명은 대문자로 시작하는 것이 관례
		 Week.java
		 변수 명은 소문자로 시작하는 것이 관례
		 score

		 변수 이름에 한글을 포함하지 않는 것이 관례이다.






		 */
		//				double x  = 3.14;
		//				int y = 2;
		//				int result = (int) x + y;
		//				System.out.print(result);

		//		int z = 10;

		//		float  킬 = 153.6f;
		//		double 키 = 153.6;
		//		int 몸무게 = 45;
		//		int 나이 = 20;

		//		System.out.println("키" + 키 + "몸무게" + 몸무게 + "나이" + 나이);
		//		System.out.printf("키: %f , 몸무게 : %d, 나이 : %d" + 키 + 몸무게 + 나이);
		//		System.out.print("\n키" + 키 + "몸무게" + 몸무게 + "나이" + 나이);
		boolean offset = false;
		//39p 자료형 타입에 대해서 공부함

		char vall = 'A';
		System.out.println(vall);
		System.out.println(offset);
		
		
				
	}
}
