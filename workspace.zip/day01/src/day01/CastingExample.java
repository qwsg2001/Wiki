package day01;

public class CastingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int var1 = 10;
		byte var2 = (byte)var1;
		
		double var3 = 3.14;
		int var4 = (int) var3;
		
		
		System.out.println(var1);
		System.out.println(var3);
		
		if(var3 == var4) {
			System.out.println("두수는 같다.");			
		}else
			System.out.println("두수는 같지않다.");			
		
		
		char v6 = 'A';
		char v7 = 1;
		int result = v6 + v7;
		System.out.println("result : " + result);			
		System.out.println("result : " + (char)result);
		System.out.println((int)v6);
		

		

	}

}
